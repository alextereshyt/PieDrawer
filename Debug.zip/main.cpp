#define _CRT_SECURE_NO_WARNINGS
#include <SFML/Graphics.hpp>
#include <iostream>
#include <time.h>
#define ALLOC_SIZE 1024*1000 
const short size1 = 600;
const short size2 = 600;
using namespace std;
using namespace sf;
struct cell {
	unsigned short type: 2;
	 unsigned short color1 : 8;
	 unsigned short color2 : 8;
	 unsigned short color3 : 8;
};

bool check(cell **matrix, int p1, int p2) {
	if (p1 >= 0 && p2 >= 0 && p1 < size1 && p2 < size2&& matrix[p1 ][p2].type == 0)
		return 0;
	return 1;
}
void clone(cell* donorcell, cell* clone) {
	clone->type = donorcell->type;

		clone->color1 = donorcell->color1;
		clone->color2 = donorcell->color2;
		clone->color3 = donorcell->color3;

}
void clone(cell* donorcell, cell* clone, int r, int g, int b) {
	clone->type = donorcell->type;

	clone->color1 = r;
	clone->color2 = g;
	clone->color3 = b;
}
void kill(cell* cell) {
	cell->type = 0;
    cell->color1 = 0;
	cell->color2 = 0;
	cell->color3 = 0;
}
void move(cell* donorcell, cell* clone) {
	clone->type = donorcell->type;
	clone->color1 = donorcell->color1;
	clone->color2 = donorcell->color2;
	clone->color3 = donorcell->color3;
	kill(donorcell);
}
int main()
{
	//inizial
	int seed = time(0);
	srand(seed); 
	cell **matrix = new cell* [size1];
    for (int i = 0; i < size1; i++)
		matrix[i] = new cell[size2];
	int wtime = 0;
	int modepar;
	int maincolor[3];
	int colorcof;
	cout << "Enter mode (Generates patern)(0 - sharp edges, 1> - smooth):  ";
	cin >> modepar;
	cout << "Enter main color(r,g,b):  ";
	cin >> maincolor[0];
	cin >> maincolor[1];
	cin >> maincolor[2];
	if (maincolor[0] <= 0)maincolor[0] = 1;
	if (maincolor[1] <= 0)maincolor[1] = 1;
	if (maincolor[2] <= 0)maincolor[2] = 1;
	cout << "Enter color change range(10 - default):  ";
	cin >> colorcof;
	for (int i = 0; i < size1; i++)
		for (int j = 0; j < size2; j++) {
			matrix[i][j].type = 0; 
			matrix[i][j].color1 = 222;
			matrix[i][j].color2 = 224;
			matrix[i][j].color3 = 213;
		}



	int ucord1=-1, ucord2=-1;
	while (check(matrix, ucord1, ucord2) && check(matrix, ucord1 + 3, ucord2) && check(matrix, ucord1, ucord2 + 3) )
	{
		cout << "Enter seed cords(x,y): ";
		cin >> ucord1 >> ucord2;

	}
	//start
	cout << "!RENDERING!" << endl;

	//first gen


	for (int i = ucord1 ; i < ucord1 + 3; i++)
		for (int j = ucord2; j < ucord2 + 3; j++) {
			matrix[i][j].type = 1;

			matrix[i][j].color1= maincolor[0];
			matrix[i][j].color2 = maincolor[1];
			matrix[i][j].color3= maincolor[2];

		}


	RenderWindow window(VideoMode(size1,size2), "PieDrawer v1");
	auto icon = Image{};
	if (!icon.loadFromFile("ico.png"))
	{
		cout << "Cant load icon!\n";
	}
	window.setIcon(icon.getSize().x, icon.getSize().y, icon.getPixelsPtr());
	
	




	while (window.isOpen())
	{


		Event event;
		while (window.pollEvent(event))
		{

			if (event.type == Event::Closed) {
				window.close();
				return 0;
			}
			
		}
		vector<RectangleShape> pixels;
		

		//++
		int c = 0;
		for (int i = 0; i < size1; i++)
			for (int j = 0; j < size2; j++) {
				if (matrix[i][j].type == 1) {
					if (modepar == 0||(rand() % modepar) == 0) {
						for (int p1 = -1; p1 < 2; p1++)
							for (int p2 = -1; p2 < 2; p2++)
							{

								if (check(matrix, p1 + i, p2 + j) == 0) {
									int r, g, b;
									r = matrix[i][j].color1 + (rand() % colorcof - (colorcof / 2));
									g = matrix[i][j].color2 + (rand() % colorcof - (colorcof / 2));
									b = matrix[i][j].color3+ (rand() % colorcof - (colorcof / 2));
									if (r > 255)r = 255;
									if (r < 1)r = 1;
									if (g > 255)g = 255;
									if (g < 1)g = 1;
									if (b > 255)b = 255;
									if (b < 1)b = 1;
									clone(&matrix[i][j], &matrix[p1 + i][p2 + j], r, g, b);
									
								}

							}
						matrix[i][j].type = 2;
					}

				}
				if (matrix[i][j].type == 0 )c++;


			}
		


	

			for (int i = 0; i < size1; i++)
				for (int j = 0; j < size2; j++) {
					RectangleShape pixel;
					pixel.setSize({ 1.f, 1.f });
					pixel.setFillColor({(Uint8)matrix[i][j].color1, (Uint8)matrix[i][j].color2,(Uint8)matrix[i][j].color3});
					Vector2f px(i,j);
					pixel.setPosition(px);
					pixels.push_back(pixel);
					//delete pixel;
					}
			for (const auto& pixel : pixels)
			{
				window.draw(pixel);
			}
			window.display();
				cout << c <<" pixels remains"  << endl;
				if (c == 0) {
					Texture texture;
					cout << "Done!\nOperations made " << wtime << "\nSeed " << seed << endl;
					texture.create(window.getSize().x, window.getSize().y);
					texture.update(window);
					cout << "Enter path to save render: ";
					char filename[200];
					cin >> filename;
					char file[100];
					strcpy(file, "render");
					char buff[100];

					_itoa(seed, buff, 10);
					strcat(file, buff);
					strcat(file, ".jpg");
					strcat(filename, file); int re;
					if (texture.copyToImage().saveToFile(filename))re = 0;
					else re = 1;
					for (; re;){
						cout << "Enter path to save render: ";
					cin >> filename;
					strcat(filename, file);
					re = texture.copyToImage().saveToFile(filename);

				     }
					cout << "Render saved to " << filename << endl;
					delete [] matrix;
					return 0;
					
				}
				wtime++;


			}
		delete[] matrix;
		return 0;

	}



